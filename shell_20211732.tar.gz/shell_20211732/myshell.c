#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<errno.h>
#include<string.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<readline/readline.h>


int main(int argc, char* argv[])
{
    pid_t pid;
    int status;

    char* cmdline;
    char* opt;
    char* opt_arr[10];
    
    int i = 0;

    while(1) {
	    int i = 0;
	    cmdline = readline("$ ");
	        
	    opt = strtok(cmdline, " \n");

	    if(!strcmp(opt, "quit"))
                    break;
	    
	    while(opt != NULL){
		    opt_arr[i] = opt;
		    opt = strtok(NULL, " \n");
		    i++;
	    }

	    opt_arr[i] = NULL;

	    pid = fork();
		
	    if (pid == 0)
		    execvp(opt_arr[0], opt_arr);

	    else
		    wait(&status);
    } 
    exit(0);


    return 0;
}

