#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<sys/errno.h>
#include<string.h>

int main(int argc, char* argv[])
{	
	pid_t pid;
        pid = fork();

	int status;

	if (pid > 0){
                //printf("I am parent: my pid = %d\n", pid);

		printf("processing ...\n");
		wait(&status);
		printf("completed.\n");
	}
        else{
                //printf("I am child: my pid = %d\n", getpid());
		execvp(argv[1], &argv[1]);

		if(execvp(argv[1], &argv[1]) == -1){
                printf("%s\n", strerror(errno));
                }

        }
        return 0;


}
